/* abedherb.com foreign edge: only visitors with a non-Iranian IP (VPN / abroad) reach this server.
   Shaparak bank gateways refuse non-Iranian IPs, so stop online payment here and ask to turn VPN off.
   Offline methods (proforma = cheque, bank transfer, cash on delivery) are allowed. */
(function () {
	var OFFLINE = ['cheque', 'bacs', 'cod'];
	var SEL = 'form.checkout, form.woocommerce-checkout, form#order_review';

	function method(f) {
		var r = f.querySelector('input[name="payment_method"]:checked');
		if (r) return r.value;
		var h = f.querySelector('input[name="payment_method"]');
		return h ? h.value : '';
	}

	function modal() {
		if (document.getElementById('abed-vpn-m')) return;
		var m = document.createElement('div');
		m.id = 'abed-vpn-m';
		m.setAttribute('role', 'dialog');
		m.setAttribute('aria-modal', 'true');
		m.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(20,24,20,.55);display:flex;align-items:center;justify-content:center;padding:16px;direction:rtl;font-family:inherit';
		m.innerHTML =
			'<div style="background:#fff;color:#1d2a1f;max-width:420px;width:100%;border-radius:14px;padding:22px 20px;box-shadow:0 12px 40px rgba(0,0,0,.25);text-align:center;line-height:1.9">' +
			'<div style="font-size:40px;line-height:1">🔒</div>' +
			'<h3 style="margin:8px 0 6px;font-size:18px;color:#2f6b3a">لطفاً VPN را خاموش کنید</h3>' +
			'<p style="margin:0 0 6px;font-size:14.5px">درگاه‌های بانکی ایران (شاپرک) با VPN یا اینترنت خارج از ایران باز نمی‌شوند و پرداخت انجام نمی‌شود.</p>' +
			'<p style="margin:0 0 16px;font-size:14.5px">VPN را خاموش کنید، صفحه را دوباره باز کنید و بعد روی دکمهٔ پرداخت بزنید. سبد خرید شما محفوظ است.</p>' +
			'<button type="button" style="background:#2f6b3a;color:#fff;border:0;border-radius:10px;padding:10px 26px;font:inherit;font-size:15px;cursor:pointer">متوجه شدم</button>' +
			'</div>';
		function close() { m.remove(); }
		m.querySelector('button').addEventListener('click', close);
		m.addEventListener('click', function (e) { if (e.target === m) close(); });
		document.body.appendChild(m);
		m.querySelector('button').focus();
	}

	function blocked(f) {
		return OFFLINE.indexOf(method(f)) === -1;
	}

	// Capture phase on document runs before WooCommerce's own submit handlers on the form.
	document.addEventListener('submit', function (e) {
		var f = e.target;
		if (f && f.matches && f.matches(SEL) && blocked(f)) {
			e.preventDefault();
			e.stopImmediatePropagation();
			modal();
		}
	}, true);
	document.addEventListener('click', function (e) {
		var b = e.target && e.target.closest ? e.target.closest('#place_order') : null;
		var f = b && b.form;
		if (f && f.matches(SEL) && blocked(f)) {
			e.preventDefault();
			e.stopImmediatePropagation();
			modal();
		}
	}, true);
	// Fallback for themes that submit checkout via jQuery without a native submit event.
	if (window.jQuery) {
		window.jQuery(function ($) {
			$('form.checkout').on('checkout_place_order', function () {
				if (blocked(this)) { modal(); return false; }
			});
		});
	}
})();
